﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $rootnamespace$;

public class $safeitemname$
{
    #region Fields

    #endregion

    #region Events

    #endregion

    #region Properties

    #endregion

    #region Constructors
    public $safeitemname$()
    {

    }

    #endregion

    #region Private Methods

    #endregion

    #region Public Methods

    #endregion

    #region Event Handler delegates

    #endregion
}
